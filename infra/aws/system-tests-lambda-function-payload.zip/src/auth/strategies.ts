export { DidSignAuth } from "./strategies/DidSignAuth";
export { HeaderKeyAuth } from "./strategies/HeaderKeyAuth";
