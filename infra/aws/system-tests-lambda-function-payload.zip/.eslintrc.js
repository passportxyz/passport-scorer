module.exports = {
  parser: "@typescript-eslint/parser",
  extends: ["plugin:@typescript-eslint/recommended", "plugin:jest/recommended", "prettier"],
  plugins: ["@typescript-eslint", "jest"],
  env: {
    node: true,
    jest: true,
  },
};
